export class Artist {
    Id: number;
    Name: string;
}