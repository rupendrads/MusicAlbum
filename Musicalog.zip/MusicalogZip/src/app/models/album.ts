export class Album {
    Id: number;
    Name: string;
    ArtistId: number;
    Label: string;
    Type: string;
    Stock: number;
    Artist: { Id: number, Name: string}
  }