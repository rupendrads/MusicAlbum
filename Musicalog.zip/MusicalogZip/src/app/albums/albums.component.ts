import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {MatTableDataSource} from '@angular/material/table';
import {MatSort} from '@angular/material/sort';
import {MatPaginator} from '@angular/material/paginator';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import {MatSnackBar} from '@angular/material/snack-bar';

import { AlbumDetailsComponent } from '../album-details/album-details.component';
import { Album } from '../models/album';
import { AlbumService } from '../services/album.service';
import { ConfirmDialogComponent } from '../shared/confirm-dialog.component';

@Component({
  selector: 'app-albums',
  templateUrl: './albums.component.html',
  styleUrls: ['./albums.component.css']
})
export class AlbumsComponent implements OnInit, OnDestroy {
  id: number = 0;
  albums: Album[] = [];

  displayedColumns: string[] = ['Name', 'Artist', 'Label', 'Type', 'Stock', 'edit', 'delete'];
  dataSource: MatTableDataSource<Album>;

  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  
  constructor(private albumService: AlbumService,
    private route: ActivatedRoute,
    private router: Router,
    public matDialog: MatDialog,
    private _snackBar: MatSnackBar) { }

  ngOnInit() {
    this.getAlbums();
  }

  getAlbums() {
    this.albums = [];
    this.albumService.getAlbums().subscribe(albums => {      
      this.albums.push(...albums);  
      this.dataSource = new MatTableDataSource(this.albums);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }

  onCreate() {
    // this.router.navigate(['../albumdetails/', this.id]);
    this.openModal(this.id);
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  onEdit(id) {
    this.id = id;
    // this.router.navigate(['../albumdetails/', this.id]);
    this.openModal(this.id);
  }

  onDelete(id) {
    var result = confirm("Are you sure to delete this album?");
    // const dialogConfig = new MatDialogConfig();
    // // The user can't close the dialog by clicking outside its body
    // dialogConfig.disableClose = true;
    // dialogConfig.id = "app-confirm-dialog";
    // dialogConfig.height = "100px";
    // dialogConfig.width = "200px";

    // this.matDialog.open(ConfirmDialogComponent, dialogConfig);
    if(result) {
    this.id = id;
    this.albumService.deleteAlbum(id).subscribe(result => {
      const index = this.albums.findIndex(a => a.Id == id);
      if(index > -1) {
        this.albums.splice(index, 1);
        this.dataSource = new MatTableDataSource(this.albums);      
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }            
        this.id = 0;
      })
    }
  }

  openModal(id) {
    const dialogConfig = new MatDialogConfig();
    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    dialogConfig.id = "app-album-details";
    dialogConfig.height = "550px";
    dialogConfig.width = "550px";
    dialogConfig.data = {id: id};
    // https://material.angular.io/components/dialog/overview
    const modalDialog = this.matDialog.open(AlbumDetailsComponent, dialogConfig);

    modalDialog.afterClosed().subscribe(result => {
      //console.log(result);
      if(result === 'data-saved')
      {
        //alert('Album saved successfully');
        this._snackBar.open('Album saved successfully','info', { duration: 2000});
        this.id = 0;
        this.getAlbums();
      }
      this.id = 0;     
    });
  }

  ngOnDestroy() {
    this.albums = [];
  }
}
