import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Artist } from '../models/artist';

@Injectable({
    providedIn: 'root',
  })
export class ArtistService {
    constructor(private http: HttpClient) {
    }    

    getArtists(): Observable<Artist[]>{
        const artists: Artist[] = [];        
        return this.http.get<Artist[]>('https://localhost:44386/api/artist')
        .pipe(map((responseData: Artist[]) => {              
            responseData.forEach(element => {
                const art = {
                    Id: element.Id,
                    Name: element.Name,                                    
                };

                artists.push(
                    art
                );                 
            });
            return artists;
        })
        );
      }
}