import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

import { Album } from '../models/album';


@Injectable({
    providedIn: 'root',
  })
export class AlbumService {    
    constructor(private http: HttpClient) {
    }    

    getAlbum(id): Observable<Album> {
        return this.http.get<Album>('https://localhost:44386/api/album/' + id + '')
        .pipe(map((responseData: Album) => {                      
            return responseData;
        })
        );

    }

    getAlbums(): Observable<Album[]>{
        const albums: Album[] = [];        
        return this.http.get<Album[]>('https://localhost:44386/api/album')
        .pipe(map((responseData: Album[]) => {              
            responseData.forEach(element => {
                const alb = {
                    Id: element.Id,
                    Name: element.Name,
                    ArtistId: element.ArtistId,
                    Artist: element.Artist,                    
                    Label: element.Label,
                    Type: element.Type.trim(),                        
                    Stock: element.Stock,                    
                };

                albums.push(
                    alb
                );                 
            });
            return albums;
        })
        );

        //return of(this.albums);
      }

      GetUniqueStatus(id: number, name: string, artist: string) {
        return this.http.get('https://localhost:44386/api/album/' + id + '/' + name + '/' + artist)
        .pipe(map((status: boolean) => {                      
            return status;
        })
        );
      }

      saveAlbum(Id: number,
                Name: string,
                Stock: number,
                Type: string,
                Label: string,
                ArtistId: number,
                Artist: { Id: number, Name: string}) { 
            console.log(Id);

            let album: Album = new Album();
            album.Name = Name;
            album.ArtistId = ArtistId;
            album.Stock = Stock;
            album.Label = Label;
            album.Type = Type;

          let url: string;
          
          if(Id > 0)  {
            url = 'https://localhost:44386/api/album/' + Id;
            album.Id = Id; 
            return this.http.put<Album>(url,
              album,
              {          
                responseType: 'json'
              })           
          } else {
            url = 'https://localhost:44386/api/album';
            return this.http.post<Album>(url,
              album,
              {          
                responseType: 'json'
              })
          } 
    }

    deleteAlbum(id: number) {
      let url: string;
      url = 'https://localhost:44386/api/album/' + id;

      return this.http.delete(url,
        {          
          responseType: 'json'
        });
    }
}