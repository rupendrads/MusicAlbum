import { Component, OnInit, Input, ViewChild, Inject } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {MatSnackBar} from '@angular/material/snack-bar';

import { Artist } from '../models/artist';
import { AlbumService } from '../services/album.service';
import { ArtistService } from '../services/artist.service';

@Component({
  selector: 'app-album-details',
  templateUrl: './album-details.component.html',
  styleUrls: ['./album-details.component.css']
})
export class AlbumDetailsComponent implements OnInit { 
  @ViewChild('f', null) albumForm: NgForm;
  id = 0;
  name = '';
  stock = 0;
  type = '';  
  label = '';
  artistId = 0;
  artist = {Id: 0, Name: ''}
  submitted = false;
  isEdit: boolean = false;

  artistList: Artist[] = [];

  constructor(private route: ActivatedRoute,
    private albumService: AlbumService,
    private artistService: ArtistService,
    private router: Router,
    public dialogRef: MatDialogRef<AlbumDetailsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {id: number},
    private _snackBar: MatSnackBar) { }

  ngOnInit() {
    //this.id = +this.route.params['id'];
    console.log(this.data);
    this.id = this.data.id;

    if(this.id > 0) {
      this.getAlbum();
    }

    this.getArtists();

    // this.route.params.subscribe(
    //   (params: Params) => {
    //     this.id = +params['id'];
    //     if(this.id > 0) {
    //       this.getAlbum();
    //     }
    //   }
    // );
    
    this.artistList = [
      // {
      //   Id: 1,
      //   Name: 'Rafi'
      // },
      // {
      //   Id: 2,
      //   Name: 'Lata'
      // },
      // {
      //   Id: 3,
      //   Name: 'Alka'
      // }
    ]    
  }

  getAlbum() {
    this.albumService.getAlbum(this.id)
    .subscribe(album => {
      this.id = album.Id;
      this.albumForm.setValue({
        name: album.Name,
        stock: album.Stock,
        type: album.Type,
        label: album.Label,
        artistId: album.ArtistId
      });     
    });
  }

  getArtists() {
    this.artistService.getArtists().subscribe(artists => {
      this.artistList = artists;
    })
  }

  onSubmit(){  
    this.submitted = true;   
    this.name = this.albumForm.value.name;
    this.stock = this.albumForm.value.stock;
    this.type = this.albumForm.value.type;
    this.label = this.albumForm.value.label;
    this.artistId = this.albumForm.value.artistId;
    this.artist = { Id: this.artistId, Name: 'KK'};

    const artist = this.artistList.find(a => a.Id == this.artistId);
    if(artist) {
      this.albumService.GetUniqueStatus(this.id, this.name, artist.Name).subscribe(status => {
        if(status) {
          this.Save();
        }
        else {
          //alert('Album should be unique');
          this._snackBar.open('Album should be unique','info', { duration: 5000});
        }
      });
    }
  }

  Save() {
    this.albumService.saveAlbum( 
      this.id,
      this.name,
      this.stock,
      this.type,            
      this.label,
      this.artistId,
      this.artist
    ).subscribe(responseData => {
      //this.router.navigate(['../albums/']);
      this.id = 0;
      this.dialogRef.close('data-saved');
    }, error => {
      console.log(error);
    });
  }

  onClose() {
    this.id = 0;
    this.dialogRef.close();
  }
}
